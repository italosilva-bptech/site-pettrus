"use client"

import Image from "next/image"
import { Shield, Car, Flame, TreePine, AlertTriangle, Zap, Phone, Truck, Disc, Key, Wrench, Fuel } from "lucide-react"
import { Button } from "./ui/button"

const coverages = [
  {
    icon: Shield,
    title: "Roubo e furto",
    description: "Amparo em situações inesperadas, com suporte ágil para minimizar impactos.",
  },
  {
    icon: Car,
    title: "Colisões",
    description: "Assistência completa para recuperação do seu veículo com eficiência.",
  },
  {
    icon: Flame,
    title: "Incêndio acidental",
    description: "Cobertura para ocorrências imprevistas, com atendimento rápido.",
  },
  {
    icon: TreePine,
    title: "Danos da natureza",
    description: "Proteção contra eventos naturais como enchentes, chuvas intensas e outros fenômenos.",
  },
  {
    icon: AlertTriangle,
    title: "Atos de vandalismo",
    description: "Mais segurança diante de situações externas fora do seu controle.",
  },
  {
    icon: Zap,
    title: "Socorro emergencial",
    description: "Atendimento imediato para garantir suporte no momento em que você mais precisa.",
  },
]

const services = [
  { icon: Phone, title: "Assistência 24h", description: "Disponibilidade total para atender você a qualquer momento." },
  { icon: Fuel, title: "Pane seca", description: "Solução prática para imprevistos simples do dia a dia." },
  { icon: Truck, title: "Guincho", description: "Rapidez no atendimento e deslocamento do veículo com segurança." },
  { icon: Disc, title: "Troca de pneus", description: "Atendimento ágil para garantir sua mobilidade." },
  { icon: Wrench, title: "Suporte técnico", description: "Orientação especializada para diferentes situações." },
  { icon: Key, title: "Chaveiro 24h", description: "Acesso facilitado em situações emergenciais." },
]

export function ServicesSection() {
  const scrollToForm = () => {
    const formSection = document.getElementById("formulario")
    if (formSection) {
      formSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="servicos" className="relative">
      {/* Hero Section with Background */}
      <div className="relative min-h-[450px] overflow-hidden">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image.png-WcqqMQZrAk0ZxRM6tW3EgKcsWWvHIC.jpeg"
          alt="Homem feliz com as chaves do carro"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-[#1a2744]/90" />
        
        <div className="relative container mx-auto px-4 py-20 lg:py-28 text-center">
          <h2 className="font-heading text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-5 max-w-2xl mx-auto leading-tight">
            Soluções completas para proteger o seu patrimônio!
          </h2>
          <p className="text-white/80 text-base md:text-lg mb-8 max-w-xl mx-auto">
            Suporte contínuo, pensado para acompanhar você em diferentes situações do dia a dia.
          </p>
          <Button
            onClick={scrollToForm}
            className="bg-white hover:bg-white/95 text-[#1a2744] rounded-full px-10 py-5 text-base font-medium shadow-lg"
          >
            Faça sua cotação agora
          </Button>
        </div>
      </div>

      {/* Coverages Section */}
      <div className="py-20 lg:py-28 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="font-heading text-xl md:text-2xl lg:text-3xl font-bold text-foreground text-center mb-14">
            Coberturas que fazem a diferença quando você mais precisa.
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {coverages.map((coverage, index) => (
              <div
                key={index}
                className="bg-white border border-border rounded-xl p-6 hover:shadow-md hover:border-[#4a90d9]/30 transition-all group"
              >
                <div className="w-12 h-12 bg-[#e8f4fd] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#4a90d9]/20 transition-colors">
                  <coverage.icon className="w-6 h-6 text-[#4a90d9]" />
                </div>
                <h4 className="font-heading text-base font-semibold text-foreground mb-2">
                  {coverage.title}
                </h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {coverage.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Services with Shield */}
      <div className="py-20 lg:py-28 bg-[#f8fafc]">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Shield Image */}
            <div className="relative h-[350px] lg:h-[400px] flex items-center justify-center order-2 lg:order-1">
              <div className="relative">
                <svg viewBox="0 0 200 250" className="w-48 h-64 lg:w-56 lg:h-72 drop-shadow-xl">
                  <defs>
                    <linearGradient id="shieldGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#4a90d9" />
                      <stop offset="100%" stopColor="#2a5a99" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M100 10L180 35V110C180 170 140 200 100 220C60 200 20 170 20 110V35L100 10Z"
                    fill="url(#shieldGrad2)"
                  />
                  <path
                    d="M80 105L95 125L130 80"
                    stroke="white"
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                  />
                </svg>
              </div>
            </div>

            {/* Services Content */}
            <div className="order-1 lg:order-2">
              <h3 className="font-heading text-xl md:text-2xl lg:text-3xl font-bold text-foreground mb-10 leading-tight">
                Uma estrutura preparada para te atender com agilidade e eficiência.
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {services.map((service, index) => (
                  <div key={index} className="flex gap-3">
                    <div className="w-10 h-10 bg-[#e8f4fd] rounded-lg flex items-center justify-center flex-shrink-0">
                      <service.icon className="w-5 h-5 text-[#4a90d9]" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground text-sm mb-1">{service.title}</h4>
                      <p className="text-muted-foreground text-xs leading-relaxed">{service.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
