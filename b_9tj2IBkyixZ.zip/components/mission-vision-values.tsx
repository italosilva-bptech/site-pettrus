import { Target, Eye, Shield, Users, Award, Heart, Search, CheckCircle } from "lucide-react"

export function MissionVisionValues() {
  return (
    <section className="py-20 lg:py-28 bg-[#f8fafc]">
      <div className="container mx-auto px-4">
        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-6 mb-20">
          {/* Mission */}
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-border">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-[#e8f4fd] rounded-lg flex items-center justify-center">
                <Target className="w-5 h-5 text-[#4a90d9]" />
              </div>
              <h3 className="font-heading text-xl font-bold text-foreground">Missão</h3>
            </div>
            <p className="text-muted-foreground leading-relaxed text-sm">
              Oferecer soluções eficientes em proteção patrimonial, garantindo a tranquilidade de nossos associados através de um atendimento de excelência e processos simplificados.
            </p>
          </div>

          {/* Vision */}
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-border">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-[#e8f4fd] rounded-lg flex items-center justify-center">
                <Eye className="w-5 h-5 text-[#4a90d9]" />
              </div>
              <h3 className="font-heading text-xl font-bold text-foreground">Visão</h3>
            </div>
            <p className="text-muted-foreground leading-relaxed text-sm">
              Ser reconhecida como a principal referência nacional em associação de proteção patrimonial, destacando-se pela inovação, confiabilidade e pelo forte senso de comunidade entre nossos membros.
            </p>
          </div>
        </div>

        {/* Values */}
        <div className="flex flex-col lg:flex-row gap-10 items-start">
          {/* Values Title */}
          <div className="lg:w-1/4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-[#e8f4fd] rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-[#4a90d9]" />
              </div>
              <h3 className="font-heading text-xl font-bold text-foreground">Nossos Valores</h3>
            </div>
            <p className="text-muted-foreground text-sm">
              Os pilares que sustentam nosso compromisso com você e seu patrimônio.
            </p>
          </div>

          {/* Values Grid */}
          <div className="lg:w-3/4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[
              { icon: Search, title: "Transparência", description: "Atuamos com clareza e ética em cada processo." },
              { icon: CheckCircle, title: "Comprometimento", description: "Assumimos a responsabilidade de cuidar de cada associado com seriedade." },
              { icon: Heart, title: "Confiança", description: "Fortalecemos relações duradouras baseadas no respeito e na integridade." },
              { icon: Award, title: "Excelência", description: "Buscamos eficiência e proximidade em cada interação." },
              { icon: Users, title: "Valorização Humana", description: "Colocamos as pessoas no centro de tudo o que fazemos." },
            ].map((value, index) => (
              <div key={index} className="bg-white rounded-xl p-5 text-center shadow-sm border border-border">
                <div className="w-11 h-11 bg-[#e8f4fd] rounded-lg flex items-center justify-center mx-auto mb-3">
                  <value.icon className="w-5 h-5 text-[#4a90d9]" />
                </div>
                <h4 className="font-heading font-semibold text-foreground text-sm mb-2">{value.title}</h4>
                <p className="text-muted-foreground text-xs leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
